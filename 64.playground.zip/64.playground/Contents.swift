import UIKit

class AgeManipulator {
    let DOB: Date
    let currentDate: Date
    let formatter = DateFormatter()
    var age: Int?
    
    init(format: String, birthday: String, today: String) {
        self.formatter.dateFormat = format
        self.DOB = formatter.date(from: birthday)!
        self.currentDate = formatter.date(from: today)!
        self.age = calculateAge()
        
    }
    
    //calculate the age of the individual
    func calculateAge() -> Int? {
        var age = Calendar.current.dateComponents([.year], from: self.DOB, to: self.currentDate)
        var years = age.year ?? 0
        return years
    }
    
    //using the current age of the individual, determines how many years until the target age
    func timeToAge(ageGoal: Int) -> Int? {
        let timeToGo = ageGoal - (self.age ?? 0)
        return timeToGo
    }
    
    //returns the year after a specified number of years (from current date)
    func yearAfterYears(ageGoal: Int) -> String {
        let baseYear = Calendar.current.dateComponents([.year], from: self.currentDate).year ?? 0
        return String(baseYear + timeToAge(ageGoal: 64)!)
    }
    

}
print("Today is 2025-1-26")
print("My birthday is 2002-01-08")
print("what year am I 64?")
var individual = AgeManipulator(format: "yyyy-MM-dd", birthday: "2002-01-08",today: "2025-1-26")
print(individual.yearAfterYears(ageGoal: 64))
