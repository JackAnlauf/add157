import UIKit


//using a list, return a number NOT already in that list
func generateNewNumber(list: [Int]) -> Int {
    while true {
        var number = Int.random(in: 1...100)
        if list.contains(number) {
        }
        else {
            return number
        }
    }
    
}
//generate a list of unique random numbers
func generateRandomNumbers(total: Int) -> [Int] {
    var newList: [Int] = []
    var count = 0
    var number: Int
    while count < total {
        number = Int.random(in: 1...100)
        if newList.contains(number) {
            count += 0
        }
        else {
            count += 1
            newList.append(number)
        }
    }
    return newList
 
    
}

//create the list of random unique numbers to use later
var numbersList = generateRandomNumbers(total: 10)
print ("numbersList: ",numbersList)


//variables a-e assigned at random
var a = numbersList[0]
var b = numbersList[1]
var c = numbersList[2]
var d = numbersList[3]
var e = numbersList[4]

//constants v-z assigned at random
let v = numbersList[5]
let w = numbersList[6]
let x = numbersList[7]
let y = numbersList[8]
let z = numbersList[9]

//place all variables into a single array
var numbersArray = [a,b,c,d,e,v,w,x,y,z]
print("numbersArray: ", numbersArray)

//sort the array in ascending order
numbersArray.sort()
print("numbersArraySorted: ", numbersArray)

//save a copy for comparison later
var numbersArrayCopy = numbersArray

//storing the sorted values into a dict, with 1 being the lowest and 10 the highest
var numbersDict: [Int:Int] = [:]

numbersDict[1] = numbersArray[0]
numbersDict[2] = numbersArray[1]
numbersDict[3] = numbersArray[2]
numbersDict[4] = numbersArray[3]
numbersDict[5] = numbersArray[4]
numbersDict[6] = numbersArray[5]
numbersDict[7] = numbersArray[6]
numbersDict[8] = numbersArray[7]
numbersDict[9] = numbersArray[8]
numbersDict[10] = numbersArray[9]


print("numbersDict: ", numbersDict)


//progress through the numbers dictionary from lowest to highest
//if a number is encountered as a constant, continue to the next number
//once a variable (changeable) is found, assign it a new unique random value
//recreate the array of constants and variables (with the new variable replaced the old one)
//exit loop
var temp = 1
while temp < 11 {
    let lowestNumber = numbersDict[temp]
    if lowestNumber == a {
        print("a = ", a, " is lowest number, and is changeable")
        a = generateNewNumber(list: numbersList)
        print("a changed to: ", a)
        numbersArray = [a,b,c,d,e,v,w,x,y,z]
        temp = 11
        
    }
    else if lowestNumber == b {
        print("b = ", b, " is lowest number, and is changeable")
        b = generateNewNumber(list: numbersList)
        print("b changed to: ", b)

        numbersArray = [a,b,c,d,e,v,w,x,y,z]
        temp = 11
        
    }
    else if lowestNumber == c {
        print("c = ", c, " is lowest number, and is changeable")
        c = generateNewNumber(list: numbersList)
        print("c changed to: ", c)

        numbersArray = [a,b,c,d,e,v,w,x,y,z]
        temp = 11
        
    }else if lowestNumber == d {
        print("d = ", d, " is lowest number, and is changeable")
        d = generateNewNumber(list: numbersList)
        print("d changed to: ", d)

        numbersArray = [a,b,c,d,e,v,w,x,y,z]
        temp = 11
        
    }else if lowestNumber == e {
        print("e = ", e, " is lowest number, and is changeable")
        e = generateNewNumber(list: numbersList)
        print("e changed to: ", e)

        numbersArray = [a,b,c,d,e,v,w,x,y,z]
        temp = 11
        
    }else if lowestNumber == v {
        print("v = ", v, " is lowest number, but cannot be changed, trying again")
        temp += 1
    }else if lowestNumber == w {
        print("w = ", w, " is lowest number, but cannot be changed, trying again")
        temp += 1
    }else if lowestNumber == x {
        print("x = ", x, " is lowest number, but cannot be changed, trying again")
        temp += 1
    }else if lowestNumber == y {
        print("y = ", y, " is lowest number, but cannot be changed, trying again")
        temp += 1
    }else if lowestNumber == z {
        print("z = ", z, " is lowest number, but cannot be changed, trying again")
        temp += 1
    }
}



//recreate the numbers dictionary to demonstrate change
numbersDict = [:]

numbersDict[1] = numbersArray[0]
numbersDict[2] = numbersArray[1]
numbersDict[3] = numbersArray[2]
numbersDict[4] = numbersArray[3]
numbersDict[5] = numbersArray[4]
numbersDict[6] = numbersArray[5]
numbersDict[7] = numbersArray[6]
numbersDict[8] = numbersArray[7]
numbersDict[9] = numbersArray[8]
numbersDict[10] = numbersArray[9]


//print statements for easy visualization of the changes
numbersArrayCopy.sort()
numbersArray.sort()

print("Before: ", numbersArrayCopy)
print("After: ", numbersArray)
